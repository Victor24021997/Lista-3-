// exercicio 1 e 2 
function mudarCor(cor){
    switch(cor){
        case 1:
            document.body.style.backgroundColor = "red"
            break
        case 2:
            document.body.style.backgroundColor = "green"
            break
        case 3:
            document.body.style.backgroundColor = "blue"
            break
        case 4:
            document.body.style.backgroundColor = "yellow"
            break
    }
}

// exercicio 3 

function teste(valor){
    if( valor=="1" ){
        document.body.style.backgroundColor = 'red';
    }
    if( valor=="2" ){
        document.body.style.backgroundColor = 'green';
    }
    if( valor=="3" ){
        document.body.style.backgroundColor = 'blue';
    }
    if( valor=="4" ){
        document.body.style.backgroundColor = 'yellow';
    }
}

// exercicio 4

function sumir(muda) {
    var display = document.getElementById(muda).style.display;
    if(display == "none"){
        document.getElementById(muda).style.display = 'block';
    }
    else{
        document.getElementById(muda).style.display = 'none';
    }
}

// exercicio 5

function validateForm() {
    let form = document.forms["formulario"];
    let usuario = form["login"].value;
    let senha = form["senha"].value;
    let confirmarSenha = form["confirmarSenha"].value;

    if(senha.length>=6 && senha.length<=10){
        if(senha === confirmarSenha){
            if (usuario == "" || senha == "" || confirmarSenha == "") {
            alert("Dados faltantes");
            return false;
            }
        }
        else{
            alert("As senhas não são iguais")
        }

    }
    else{
        alert("A senha precisa possuir entre 6 e 10 caracteres")
    }
}

// exercicio 6 Feito em sala pelo professor. 

// exercicio 7

function alterar() {
    var nome = [];
    nome.push(document.getElementById("nome1").value);
    nome.push(document.getElementById("nome2").value);
    nome.push(document.getElementById("nome3").value);
    nome.push(document.getElementById("nome4").value);
    nome.push(document.getElementById("nome5").value);
    document.getElementById("nome1").value = nome[4];
    document.getElementById("nome2").value = nome[3];
    document.getElementById("nome3").value = nome[2];
    document.getElementById("nome4").value = nome[1];
    document.getElementById("nome5").value = nome[0];
}

// exercicio 8

function pessoaJuridica() {
    document.forms["Cadastrocliente"]["cpf"].disabled = true;
    document.forms["Cadastrocliente"]["cnpj"].disabled = false;
    document.forms["Cadastrocliente"]["dataNascimento"].disabled = true;
}
function pessoaFisica() {
    document.forms["Cadastrocliente"]["cpf"].disabled = false;
    document.forms["Cadastrocliente"]["cnpj"].disabled = true;
    document.forms["Cadastrocliente"]["dataNascimento"].disabled = false;
}




// exercicio 9

function intercalarP() {
    var palavra1 = document.forms["intercalar"]["palavra1"].value;
    var palavra2 = document.forms["intercalar"]["palavra2"].value;
    var array1 = palavra1.split('');
    var array2 = palavra2.split('');
    var intercalarLetras = 0;
    var resultado = "";
    if (array1.length > array2.length) {
        intercalarLetras = array1.length;
    }else{
        intercalarLetras = array2.length;
    }
    for (var i = 0; i < intercalarLetras; i++) {
        if(array1[i]){
            resultado = resultado + array1[i];
        }
        if (array2[i]) {
            resultado = resultado + array2[i];
        }
    }
    document.forms["intercalar"]["inter"].value = resultado;
   
}
